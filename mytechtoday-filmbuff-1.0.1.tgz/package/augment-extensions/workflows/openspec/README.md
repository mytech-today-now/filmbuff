# OpenSpec Workflow Module

Detailed OpenSpec workflow guidance lives here so `.augment/` can stay compact.

## What this module covers

- change creation and artifact sequencing
- apply/implement flows driven by OpenSpec instructions
- verify, sync, archive, and bulk-archive behavior
- onboarding and explore-mode guidance for OpenSpec work

## How to use it

1. Keep `.augment/commands/` and `.augment/skills/` as compact entrypoints.
2. Load this module when you need the fuller operating model.
3. Prefer the actual artifact graph from `openspec status --json` over assumptions.

## Included references

- `rules/workflow.md` — lifecycle and artifact model
- `rules/opsx-command-reference.md` — per-command behavior contracts