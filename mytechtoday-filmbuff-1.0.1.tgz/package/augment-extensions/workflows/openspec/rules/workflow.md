# OpenSpec Workflow

## Lifecycle

1. Create a change.
2. Build artifacts in dependency order.
3. Apply the change by implementing pending tasks.
4. Verify completeness, correctness, and coherence.
5. Sync delta specs when appropriate.
6. Archive the change once implementation and documentation align.

## Artifact model

- Always use `openspec status --change "<name>" --json` as the source of truth.
- `ready` artifacts may be created next.
- `blocked` artifacts require dependencies first.
- `isComplete` means artifact creation is finished, not necessarily implementation.

## Apply model

- Use `openspec instructions apply --change "<name>" --json`.
- Read every file in `contextFiles` before coding.
- Implement through the tasks, updating completed checkboxes as work lands.

## Verification model

Evaluate three dimensions:

- **Completeness** — tasks and spec requirements accounted for
- **Correctness** — implementation and tests match the intended requirements
- **Coherence** — design decisions and project patterns still line up

## Sync model

Delta specs express intent. Merging should be intelligent:

- add new requirements when absent
- partially modify existing requirements without replacing untouched content
- remove or rename only what the delta explicitly targets

## Archive model

Before archive:

- review artifact completion
- review incomplete tasks
- decide whether delta specs should be synced now
- archive to a dated path under `openspec/changes/archive/`