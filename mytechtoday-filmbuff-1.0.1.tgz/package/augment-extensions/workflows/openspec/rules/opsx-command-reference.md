# OPSX Command Reference

## `/opsx:new`

- Create a change.
- Show the first ready artifact.
- Stop before generating additional artifacts.

## `/opsx:continue`

- Create exactly one next ready artifact.
- Read dependency artifacts first.
- Re-run status and report what unlocked.

## `/opsx:ff`

- Create the change.
- Continue generating ready artifacts until `applyRequires` is satisfied.
- Hand off to implementation.

## `/opsx:apply`

- Load status and apply instructions.
- Respect blocked or already-complete states.
- Read `contextFiles`, implement the work, and update tasks.

## `/opsx:verify`

- Build a report across completeness, correctness, and coherence.
- Prefer actionable findings with file references.

## `/opsx:sync`

- Read delta and main specs together.
- Merge ADDED, MODIFIED, REMOVED, and RENAMED sections carefully.
- Keep the result idempotent.

## `/opsx:archive`

- Review artifacts, tasks, and sync state.
- Warn instead of silently blocking when user confirmation is possible.
- Archive to `YYYY-MM-DD-<name>`.

## `/opsx:bulk-archive`

- Validate multiple changes together.
- Detect shared capability conflicts.
- Resolve sync order from implementation evidence.

## `/opsx:explore`

- Think and investigate.
- You may update OpenSpec artifacts.
- Do not implement product code.

## `/opsx:onboard`

- Teach using an EXPLAIN → DO → SHOW → PAUSE rhythm.
- Prefer real artifacts and small, traceable steps.